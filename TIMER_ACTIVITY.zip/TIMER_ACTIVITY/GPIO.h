#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED

#include<avr/io.h>
#include<stdint.h>

#define SET_BIT(PORT,BIT) PORT |= (1 << BIT)
#define CLR_BIT(PORT,BIT) PORT &= ~(1 << BIT)

#define INPUT 1
#define OUTPUT 0
#define HIGH 1
#define LOW 0



void GPIOConfig(uint8_t Pin,uint8_t mode);
void GPIOPinWrite(uint8_t pin, uint8_t state);

#endif // GPIO_H_INCLUDED
