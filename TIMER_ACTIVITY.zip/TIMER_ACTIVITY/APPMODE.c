#include "APPMODE.h"
static int dutycyclevalue=125;
void GPIOPLUS()
{
    if(dutycyclevalue<250)
        dutycyclevalue=dutycyclevalue+25;
   OCR();

}

void GPIOMINUS()
{
    if(dutycyclevalue>0)
        dutycyclevalue=dutycyclevalue-25;
    OCR();

}

void OCR()
{
    OCR0A=dutycyclevalue;
    GPIOPinWrite(PD0,HIGH);
    _delay_ms(dutycyclevalue);
    GPIOPinWrite(PD0,LOW);
    _delay_ms(250-dutycyclevalue);
}
