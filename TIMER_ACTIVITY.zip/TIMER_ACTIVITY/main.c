/*
 */

#include "GPIO.h"
#include "APPMODE.h"
#include "ModeState.h"


struct {
  volatile unsigned int FLAG_ISR1: 1;
}
FLAG_BIT_T;

struct {

  volatile unsigned int FLAG_ISR11: 1;
  volatile unsigned int FLAG_ISR12: 1;
}FLAG_BIT;


volatile uint16_t counter = 0x00;

int main(void)
{
    int mode_state;
    GPIOConfig(PD7,INPUT);
    GPIOConfig(PD5,INPUT);
    GPIOConfig(PB6,INPUT);
    GPIOConfig(PD0,OUTPUT);
    // Insert code
    TCCR0A = ((1 << WGM01) | (1 << WGM00)); // Normal mode of operation
    TCCR0A |= (1 << COM0A1);
    TCCR0A &= ~(1 << COM0A0);
    TCNT0 = 0x00;

    TCCR0B |= ((1 << CS00) | (1 << CS02)); //default WGM02 settings are 0 at the time of system reset
    TCCR0B &= ~(1 << CS01); //101 --------------clk/1024(prescalar)
    TIMSK0 |= (1 << TOIE0); //Local Timer Overflow INT enable

    PCMSK2 |= (1<<PCINT21);
    PCICR |=(1<<PCIE2);

    PCMSK0 |= (1<<PCINT6);
    PCICR |=(1<<PCIE0);
    sei();

    while(1)
    {
        mode_state=modestate(PD7);
        if(mode_state==0)
        {
            if(FLAG_BIT_T.FLAG_ISR1==1)
            {
                PORTD ^=(1<<PD0);
                FLAG_BIT_T.FLAG_ISR1=0;
            }
        }
        else if(mode_state==1)
        {
            OCR();
            if(FLAG_BIT.FLAG_ISR12==1)
            {
                FLAG_BIT.FLAG_ISR12=0;
                GPIOPLUS();

            }
            else if(FLAG_BIT.FLAG_ISR11==1)
            {
                 FLAG_BIT.FLAG_ISR11=0;
               GPIOMINUS();

            }


        }
    }


}


ISR(TIMER0_OVF_vect) {
    cli();
  counter++;
    if (counter >= 61) {
    FLAG_BIT_T.FLAG_ISR1 = 1;
    counter = 0;
  }
  sei();
}

ISR(PCINT2_vect) {
    FLAG_BIT.FLAG_ISR11=1;
}

ISR(PCINT0_vect) {
    FLAG_BIT.FLAG_ISR12=1;
}
