/*
 */
#include "GPIO.h"
#include <avr/io.h>
#include<avr/delay.h>


int main(void)
{
    int pinread1,pinread2;

    // Insert code
    GPIOConfig(PD1,INPUT);
    GPIOConfig(PD2,INPUT);
     GPIOConfig(PD5,OUTPUT);
    GPIOConfig(PD6,OUTPUT);



    while(1)
    {

        pinread1=GPIOPinRead(PD1);
        pinread2=GPIOPinRead(PD2);
        if(pinread1==0 && pinread2==0)
        {
            GPIOPinWrite(PD5,LOW);
            GPIOPinWrite(PD6,LOW);
        }
        else if(pinread1==0 && pinread2==1)
        {
            GPIOPinWrite(PD5,LOW);
            GPIOPinWrite(PD6,HIGH);
        }
        else if(pinread1==1 && pinread2==0)
        {
            GPIOPinWrite(PD5,HIGH);
            GPIOPinWrite(PD6,LOW);
        }
        else
        {
            GPIOPinWrite(PD5,HIGH);
            GPIOPinWrite(PD6,HIGH);
            _delay_ms(1000);
            GPIOPinWrite(PD5,LOW);
            GPIOPinWrite(PD6,LOW);
            _delay_ms(1000);
        }
    }

    return 0;
}
