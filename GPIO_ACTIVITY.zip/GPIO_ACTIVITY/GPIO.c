//GPIO.c implementation file template

/******************************************************************************
* File Name: GPIO.c
* Description: This file contains API definitions for GPIO functionality
* Tool-Chain: AVR GCC
*
* Modification History:
* Created by: Username V1.0 27/Jul/15
* Description: V1.0
******************************************************************************/
/******************************************************************************
* Includes
******************************************************************************/
#include<avr/io.h>
#include<util/delay.h>
#include "GPIO.h"
/******************************************************************************
* Defines and data types
******************************************************************************/
/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Static variables
******************************************************************************/
/******************************************************************************
* Internal function prototypes
******************************************************************************/
/******************************************************************************
* Public functions definitions
******************************************************************************/
void GPIOConfig(uint8_t Pin, uint8_t mode)
{
    if(mode == 0)
    {
        if(Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            SET_BIT(DDRD,Pin);
        else if(Pin==PC1 ||Pin==PC2 ||Pin==PC3 ||Pin==PC4 ||Pin==PC5 ||Pin==PC6)
            SET_BIT(DDRC,Pin);
        else
            SET_BIT(DDRB,Pin);


    }
    else if(mode == 1)
    {
        if(Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
        {
            CLR_BIT(DDRD,Pin);
            SET_BIT(PORTD,Pin);
        }
        else if(Pin==PC1 ||Pin==PC2 ||Pin==PC3 ||Pin==PC4 ||Pin==PC5)
        {
            CLR_BIT(DDRC,Pin);
            SET_BIT(PORTC,Pin);
        }
        else {
            CLR_BIT(DDRB,Pin);
            SET_BIT(PORTB,Pin);
        }

    }
}

int GPIOPinRead(uint8_t Pin)
{
     uint8_t pinr=0x00000000;
        pinr=PIND;
        if(pinr & (1<<Pin))
            return 0;
        else
            return 1;
}

void GPIOPinWrite(uint8_t Pin, uint8_t state)
{
    if(state == 1)
    {

        if(Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            SET_BIT(PORTD,Pin);
        else if(Pin==PC1 ||Pin==PC2 ||Pin==PC3 ||Pin==PC4 ||Pin==PC5 ||Pin==PC6)
            SET_BIT(PORTC,Pin);
        else
            SET_BIT(PORTB,Pin);

    }

    else if(state == 0)
    {

        if(Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            CLR_BIT(PORTD,Pin);
         else if(Pin==PC1 ||Pin==PC2 ||Pin==PC3 ||Pin==PC4 ||Pin==PC5 ||Pin==PC6 ||Pin)
            CLR_BIT(PORTC,Pin);
        else
            CLR_BIT(PORTB,Pin);

    }
}


/******************************************************************************
* Name: GPIOConfig (pin, mode)
* Description: Configures the mode of the pin as INPUT/PULLUP or OUTPUT
* Arguments: pin and mode
* Returns: None
******************************************************************************/
/******************************************************************************
* Internal functions
******************************************************************************/
/******************************************************************************
* Name:
* Description:
******************************************************************************/
/******************************************************************************
/******************************************************************************
* End of File
******************************************************************************/
