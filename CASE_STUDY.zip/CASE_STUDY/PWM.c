
#include "PWM.h"
void PWM(int pwm_value)
{
  OCR0A = pwm_value;
}
