
 #include "ADC.h"
float sensor_reading;
float *V=&sensor_reading;
 void adc()
 {
     uint16_t ADC_value;
    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));
    ADC_value = ADC;
    sensor_reading = ((int)ADCH*255+(int)ADCL);
    sam();
}

void adc_call()
{
       ADMUX &= 0x00;
    ADMUX |= (1 << REFS0);
    ADCSRA |= (1 << ADEN);
}
