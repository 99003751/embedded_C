/*
 */


#include "GPIO.h"
#include "PWM.h"
#include "ADC.h"
#include <avr/interrupt.h>

volatile uint8_t FLAG_ISR0=0;
volatile uint8_t FLAG_ISR1=0;
volatile uint8_t FLAG_ISR_T=0;
volatile uint16_t counter=0x00;

int main(void)
{
    GPIOConfig(PD2,INPUT);  //ENGINE SWITCH
    GPIOConfig(PD3,INPUT);  //WIPER MODE SWITCH
    GPIOConfig(PD6,OUTPUT); //PWM OUTPUT

    CLR_BIT(EICRA,ISC11);
    SET_BIT(EICRA,ISC10);
    EIMSK|=(1<<INT1);
    SET_BIT(EICRA,ISC00);
    CLR_BIT(EICRA,ISC01);
    EIMSK|=(1<<INT0);


     TCCR0A = ((1 << WGM01) | (1 << WGM00)); // Normal mode of operation
    TCCR0A |= (1 << COM0A1);
    TCCR0A &= ~(1 << COM0A0);

    TCNT0 = 0x00;

   TCCR0B |= ((1 << CS00) | (1 << CS02)); // 1024 prescaler
     TCCR0B &= ~(1 << CS01);

   TIMSK0|=(1<<TOIE0);
    sei();

    adc_call();

    while(1){
    if(FLAG_ISR1==1 && FLAG_ISR0==1)
    {
        if(FLAG_ISR_T==1){
            FLAG_ISR_T=0;
            adc();
        }
    }
    else if(FLAG_ISR1==0 && FLAG_ISR0==1)
    {
         ADCSRA &= ~(1 << ADSC);
         PWM(127);
    }
    else
    {
         ADCSRA &= ~(1 << ADSC);
         GPIOPinWrite(PD6,LOW);
    }
    }
    return 0;
}

ISR(INT0_vect)
{
    FLAG_ISR0=FLAG_ISR0^1;
}

ISR(INT1_vect)
{
    FLAG_ISR1=FLAG_ISR1^1;
}

ISR(TIMER0_OVF_vect)
{
    counter++;
    if(counter>=305)
    {
        FLAG_ISR_T=1;
        counter=0;
    }
}

