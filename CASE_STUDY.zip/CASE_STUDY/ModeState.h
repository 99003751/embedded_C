#ifndef MODESTATE_H_INCLUDED
#define MODESTATE_H_INCLUDED


#include "GPIO.h"

int modestate(uint8_t pin);
#endif // MODESTATE_H_INCLUDED
