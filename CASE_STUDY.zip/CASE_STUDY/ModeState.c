
#include "ModeState.h"
int modestate(uint8_t pin)
{
    int pinread=0x00000000;
    pinread=PIND;
    if(pinread & (1<<pin))
        return 0;
    else
        return 1;
}
