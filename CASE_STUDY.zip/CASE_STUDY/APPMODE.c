#include "APPMODE.h"
extern float *V;
void sam()
{
    if(*V>0 && *V<=50)
    {
        PWM(0);
    }
    else if(*V>50 && *V<=200)
    {
       PWM(63);
    }
    else if(*V>200 && *V<=500)
    {
        PWM(127);
    }
    else if(*V>500 && *V<=1000)
    {
      PWM(190);
    }
    else if(*V>1000)
    {
        PWM(254);
    }
}
