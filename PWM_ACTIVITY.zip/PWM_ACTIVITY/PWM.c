#include "PWM.h"
extern int *ptr;
void OCR()
{
    OCR0A=*ptr;
    GPIOPinWrite(PD0,HIGH);
    _delay_ms(*ptr);
    GPIOPinWrite(PD0,LOW);
    _delay_ms(250-*ptr);
}
