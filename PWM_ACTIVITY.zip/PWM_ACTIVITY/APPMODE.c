#include "APPMODE.h"
static int dutycyclevalue=125;
int *ptr=&dutycyclevalue;
void GPIOPLUS()
{
    if(dutycyclevalue<250)
        dutycyclevalue=dutycyclevalue+25;

}

void GPIOMINUS()
{
    if(dutycyclevalue>0)
        dutycyclevalue=dutycyclevalue-25;
}


