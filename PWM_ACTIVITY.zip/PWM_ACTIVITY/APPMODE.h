#ifndef APPMODE_H_INCLUDED
#define APPMODE_H_INCLUDED
#include<avr/interrupt.h>
#include<avr/delay.h>
#include "GPIO.h"


void GPIOMINUS();
void GPIOPLUS();
void OCR();

#endif // APPMODE_H_INCLUDED
