/*
 */


#include "GPIO.h"
#include "APPMODE.h"
#include "ModeState.h"
struct {
  volatile unsigned int FLAG_ISR1: 1;
}
FLAG_BIT_T;

struct {

  volatile unsigned int FLAG_ISR11: 1;
  volatile unsigned int FLAG_ISR12: 1;
}FLAG_BIT;

volatile uint16_t counter = 0x00;

int main(void)
{
    int mode_state;
    GPIOConfig(PD7,INPUT);
    GPIOConfig(PD5,INPUT);
    GPIOConfig(PB6,INPUT);
    GPIOConfig(PD0,OUTPUT);
    GPIOConfig(PD1,OUTPUT);

    TCCR2A = ((1 << WGM20) | (1 << WGM21)); // Normal mode of operation
    TCCR2A |= (1 << COM2A1);
    TCCR2A &= ~(1 << COM2A0);
    TCNT2 = 0x00;

    TCCR2B |= ((1 << CS21) | (1 << CS20) | (1 << CS22)); //default WGM02 settings are 0 at the time of system reset
   // TCCR2B &= ~(1 << CS01); //101 --------------clk/1024(prescalar)
    TIMSK2 |= (1 << TOIE2); //Local Timer Overflow INT enable

    PCMSK2 |= (1<<PCINT21);
    PCICR |=(1<<PCIE2);

    PCMSK0 |= (1<<PCINT6);
    PCICR |=(1<<PCIE0);
    sei();


    while(1)
    {
         mode_state=modestate(PD7);
        if(mode_state==0)
        {
            if(FLAG_BIT_T.FLAG_ISR1==1)
            {
                PORTD ^=(1<<PD0);
                FLAG_BIT_T.FLAG_ISR1=0;
            }
            FLAG_BIT.FLAG_ISR11=0;
            FLAG_BIT.FLAG_ISR12=0;
        }
        else if(mode_state==1)
        {
            OCR();
            if(FLAG_BIT.FLAG_ISR12==1)
            {
                FLAG_BIT.FLAG_ISR12=0;
                GPIOPLUS();

            }
            else if(FLAG_BIT.FLAG_ISR11==1)
            {
                 FLAG_BIT.FLAG_ISR11=0;
               GPIOMINUS();

            }
            OCR();

        }
    }


    return 0;
}


ISR(TIMER2_OVF_vect) {
    cli();
  counter++;
    if (counter >= 61) {
    FLAG_BIT_T.FLAG_ISR1 = 1;
    counter = 0;
  }
  sei();
}

ISR(PCINT2_vect) {
    FLAG_BIT.FLAG_ISR11=1;
}

ISR(PCINT0_vect) {
FLAG_BIT.FLAG_ISR12=1;
}
