/*
 */

#include <avr/io.h>
#include<avr/interrupt.h>
#include "GPIO.h"

int main() {

    GPIOConfig(PD3,INPUT);
    GPIOConfig(PB6,INPUT);
    GPIOConfig(PB4,INPUT);
    GPIOConfig(PD7,OUTPUT);
    GPIOConfig(PD6,OUTPUT);

  PCMSK2 |= (1<<PCINT19);
  PCICR |=(1<<PCIE2);

  PCMSK0 |= (1<<PCINT6);
  PCICR |=(1<<PCIE0);
  sei();

  while (1) //super loop
  {
         FSMInit();

}
}

ISR(PCINT2_vect) {
    FLAG_BIT.FLAG_ISR1=1;
}

ISR(PCINT0_vect) {
    FLAG_BIT.FLAG_ISR2=1;
}

