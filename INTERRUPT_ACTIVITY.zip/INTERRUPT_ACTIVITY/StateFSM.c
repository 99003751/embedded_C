#include "GPIO.h"
#include<avr/delay.h>
#include <avr/io.h>


void FSMInit()
{
    FLAG_BIT.FLAG_ISR1=0;
    FLAG_BIT.FLAG_ISR2=0;
    while(1)
    {
        GPIOPinWrite(PD7,HIGH);
        GPIOPinWrite(PD6,HIGH);
        _delay_ms(2000);
        GPIOPinWrite(PD7,LOW);
        GPIOPinWrite(PD6,LOW);
        _delay_ms(2000);
        if(FLAG_BIT.FLAG_ISR1==1)
        {
            FSMStateA();
        }

    }
}

void FSMStateA()
{
    FLAG_BIT.FLAG_ISR1=0;
    FLAG_BIT.FLAG_ISR2=0;
    while(1)
    {

            GPIOPinWrite(PD7,HIGH);
            GPIOPinWrite(PD6,HIGH);
            if(FLAG_BIT.FLAG_ISR2==1)
            {
                FSMStateB();
            }
    }
}

void FSMStateB()
{
    FLAG_BIT.FLAG_ISR1=0;
    FLAG_BIT.FLAG_ISR2=0;

    while(1)
    {

            GPIOPinWrite(PD7,LOW);
            GPIOPinWrite(PD6,LOW);
            if(FLAG_BIT.FLAG_ISR1==1)
            {
                FSMInit();
            }
    }
}
