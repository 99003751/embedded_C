#include "PWM.h"

void PWM(int PWM_value)
{
    OCR0A=PWM_value;
}
