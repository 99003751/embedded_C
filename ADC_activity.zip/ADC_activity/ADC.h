
#ifndef ADC_H_INCLUDED
#define ADC_H_INCLUDED

#include "APPMODE.h"

void adc_call();
 void adc();



#endif // PWM_H_INCLUDED
