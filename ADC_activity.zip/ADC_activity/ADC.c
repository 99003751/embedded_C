 #include "ADC.h"
float voltage;
float *V=&voltage;
 void adc()
 {
     uint16_t ADC_value;
    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));
    ADC_value = ADC;
    voltage=(0.0048828125)*((int)ADCH*255+(int)ADCL);
    sam();
}

void adc_call()
{
       ADMUX &= 0x00;
  ADMUX |= (1 << REFS0);
  ADCSRA |= (1 << ADEN);
}
