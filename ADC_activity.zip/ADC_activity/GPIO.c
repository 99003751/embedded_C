#include "GPIO.h"



void GPIOConfig(uint8_t Pin, uint8_t mode)
{
    if(mode == 0)
    {
        if(Pin==PD0||Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            SET_BIT(DDRD,Pin);
        else if(Pin==PB0||Pin==PB1 ||Pin==PB2 ||Pin==PB3 ||Pin==PB4 ||Pin==PB5 || Pin==PB6)
            SET_BIT(DDRB,Pin);
        else
            SET_BIT(DDRC,Pin);



    }
    else if(mode == 1)
    {
        if(Pin==PD0 || Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
        {
            CLR_BIT(DDRD,Pin);
            SET_BIT(PORTD,Pin);
        }
        if(Pin==PB0 || Pin==PB1 ||Pin==PB2 ||Pin==PB3 ||Pin==PB4 ||Pin==PB5 || Pin==PB6)
        {
            CLR_BIT(DDRB,Pin);
            SET_BIT(PORTB,Pin);
        }
        else{
            CLR_BIT(DDRC,Pin);
            SET_BIT(PORTC,Pin);
        }

    }
}



void GPIOPinWrite(uint8_t Pin, uint8_t state)
{
    if(state == 1)
    {

        if(Pin==PD0 ||Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            SET_BIT(PORTD,Pin);
        else if(Pin==PB0 || Pin==PB1 ||Pin==PB2 ||Pin==PB3 ||Pin==PB4 ||Pin==PB5 || Pin==PB6)
            SET_BIT(PORTB,Pin);
        else
            SET_BIT(PORTC,Pin);

    }

    else if(state == 0)
    {

        if(Pin==PD0 ||Pin==PD1 ||Pin==PD2 ||Pin==PD3 ||Pin==PD4 ||Pin==PD5 ||Pin==PD6 ||Pin==PD7)
            CLR_BIT(PORTD,Pin);
        else if(Pin==PC0 || Pin==PC1 ||Pin==PC2 ||Pin==PC3 ||Pin==PC4 ||Pin==PC5 ||Pin==PC6)
            CLR_BIT(PORTC,Pin);
        else
            CLR_BIT(PORTB,Pin);

    }
}


