/*
 */


#include "GPIO.h"
#include "APPMODE.h"
#include "ModeState.h"
#include "PWM.h"
#include "ADC.h"
#include "PWM.h"
struct {
  volatile unsigned int FLAG_ISR1: 1;
}
FLAG_BIT;



volatile uint16_t counter = 0x00;

int main(void)
{
    int mode_state;
    GPIOConfig(PD5,INPUT);
    GPIOConfig(PD0,OUTPUT);
    GPIOConfig(PD6,OUTPUT);

    TCCR0A = ((1 << WGM01) | (1 << WGM00)); // Normal mode of operation
    TCCR0A |= (1 << COM0A1);
    TCCR0A &= ~(1 << COM0A0);
    TCNT0 = 0x00;
    OCR0A=64;

   TCCR0B |= ((1 << CS00) | (1 << CS02)); //default WGM02 settings are 0 at the time of system reset
    TCCR0B &= ~(1 << CS01); //1024 prescelar
   // TIMSK0 |= (1 << TOIE0); //Local Timer Overflow INT enable
    sei();
    PCMSK2 |= (1<<PCINT21);
    PCICR |=(1<<PCIE2);
    sei();

    while(1)
    {


            if(FLAG_BIT.FLAG_ISR1==1)
            {
                mode_state = modestate(PD5);
                FLAG_BIT.FLAG_ISR1=0;
                if(mode_state==0)
                {
                    GPIOPinWrite(PD0,LOW);
                    PWM(64);
                }
                else if(mode_state==1)
                {
                    GPIOPinWrite(PD0,HIGH);
                    adc_call();
                   while(1)
                   {
                       adc();
                       if(FLAG_BIT.FLAG_ISR1==1)
                        break;
                   }
                }
            }

    }

    return 0;
}


ISR(PCINT2_vect) {
    FLAG_BIT.FLAG_ISR1=1;
}


