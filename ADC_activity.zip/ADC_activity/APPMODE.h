#ifndef APPMODE_H_INCLUDED
#define APPMODE_H_INCLUDED
#include<avr/interrupt.h>
#include<avr/delay.h>
#include "GPIO.h"
#include "ADC.h"
void sam();

#endif // APPMODE_H_INCLUDED
