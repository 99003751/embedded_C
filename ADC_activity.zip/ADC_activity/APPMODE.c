#include "APPMODE.h"
extern float *V;
void sam()
{

    if(*V>=0 && *V<1.0)
    {
       PWM(64);
    }
    else if(*V>=1.0 && *V<2.0)
    {
        PWM(128);
    }
    else if(*V>=2.0 && *V<3.0)
    {
      PWM(192);
    }
    else if(*V>=3.0)
    {
        PWM(254);
    }
}
